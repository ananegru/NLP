#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NLP A4 2023
parser_transitions.py: Algorithms for completing partial parsess.
Authors: Sahil Chopra, Haoshen Hong, Nathan Schneider, Lucia Donatelli
"""

import sys

class PartialParse(object):
    def __init__(self, sentence):
        """Initializes this partial parse.

        @param sentence (list of str): The sentence to be parsed as a list of words.
                                        Your code should not modify the sentence.
        """
        # The sentence being parsed is kept for bookkeeping purposes. Do NOT alter it in your code.
        self.sentence = sentence

        ### CODING ASSIGNMENT 1
        ### TODO:
        ### YOUR CODE HERE (3 Lines)
        ### Your code should initialize the following fields:
        ###     self.stack: The current stack represented as a list with the top of the stack as the
        ###                 last element of the list.
        ###     self.buffer: The current buffer represented as a list with the first item on the
        ###                  buffer as the first item of the list
        ###     self.dependencies: The list of dependencies produced so far. Represented as a list of
        ###             tuples where each tuple is of the form (head, dependent).
        ###             Order for this list doesn't matter.
        ###
        ### Note: The root token should be represented with the string "ROOT"
        ### Note: If you need to use the sentence object to initialize anything, make sure to not directly 
        ###       reference the sentence object.  That is, remember to NOT modify the sentence object. 
   
        # Initialize the stack with only the root token, representing the current stack during parsing. 
        # The Root token provides a starting point for the parsing process.
        self.stack = ['ROOT']
        # Initialize the buffer with a copy of the sentence representing the current buffer during parsing.
        # Initializing it with a copy of the sentence allows for word-by-word processing.
        #self.buffer = list(sentence)
        self.buffer = self.sentence.copy()
        # Initialize the dependencies list as an empty list, which keeps track of the dependencies produced during parsing.
        # This allows them to be accumulated and returned as the final result.
        self.dependencies = []

        ### END YOUR CODE


    def parse_step(self, transition):
        """Performs a single parse step by applying the given transition to this partial parse

        @param transition (str): A string that equals "S", "LA", or "RA" representing the shift,
                                left-arc, and right-arc transitions. You can assume the provided
                                transition is a legal transition.
        """
        ### CODING ASSIGNMENT 2
        ### YOUR CODE HERE (~7-12 Lines)
        ### TODO:
        ###     Implement a single parsing step, i.e. the logic for the following as
        ###     described in the pdf handout:
        ###         1. Shift
        ###         2. Left Arc
        ###         3. Right Arc
        if(len(self.buffer) == 0 and len(self.stack) == 1): #check the buffer is not empty
            pass
        elif(transition == "S" and len(self.buffer) > 0):#if transition is S, shift
            self.stack.append(self.buffer.pop(0)) #first word is removed from buffer to stack using pop
        elif(transition == "LA" and len(self.stack) > 1): #if transition is LA, left-arc
            self.dependencies.append((self.stack[-1], self.stack.pop(-2))) #remove second to last item from the stack, assign it to "dependent" variable
        elif(transition == "RA" and len(self.stack) > 1):
            #if transition is RA, right-arc
            self.dependencies.append((self.stack[-2], self.stack.pop(-1))) #assign the last item in the stack to "head" variable
            #append tuple to dependency list. Represents left-arc dependency relation
        elif(transition != "S" and len(self.stack) == 1):
        #`elif(transition != "S" and len(self.stack) == 1)`: This condition checks if the transition is not "S" and there is only one word left in the stack. If true, it recursively calls the `parse_step` method with the "S" transition to shift the remaining word from the buffer to the stack.
            self.parse_step("S")
        elif(len(self.buffer) == 0 and transition == "S"):
        # elif(len(self.buffer) == 0 and transition == "S"): This condition checks if the buffer is empty and the transition is "S". If true, it randomly selects between "LA" (left-arc) and "RA" (right-arc) transitions with equal probability and recursively calls the `parse_step` method with the chosen transition.
            n = random.random()
            if n > 0.5:
                self.parse_step("LA")
            else: 
                self.parse_step("RA") 
        else: 
        #else: This code block is executed when none of the above conditions are satisfied. It is essentially a placeholder for any additional parsing transitions or operations that might be included in the algorithm.
            pass
        
        # In a left-arc transition, a dependency relation is established between the second-to-last item (dependent) on the stack and the last item (head) on the stack. 
        # By popping the second-to-last item from the stack (self.stack.pop(-2)), we isolate the dependent. 

        # In a right-arc transition, a dependency relation is established between the last item (dependent) on the stack and the second-to-last item (head) on the stack. 
        # By popping the last item from the stack (self.stack.pop(-1)), we isolate the dependent.

        ### END YOUR CODE

    def parse(self, transitions):
        """Applies the provided transitions to this PartialParse

        @param transitions (list of str): The list of transitions in the order they should be applied

        @return dependencies (list of string tuples): The list of dependencies produced when parsing the sentence. Represented as a list of tuples where each tuple is of the form (head, dependent).
        """
        for transition in transitions:
            self.parse_step(transition)
        return self.dependencies


def minibatch_parse(sentences, model, batch_size):
    """Parses a list of sentences in minibatches using a model.

    @param sentences (list of list of str): A list of sentences to be parsed
                                            (each sentence is a list of words and each word is of type string)
    @param model (ParserModel): The model that makes parsing decisions. It is assumed to have a function
                                model.predict(partial_parses) that takes in a list of PartialParses as input and
                                returns a list of transitions predicted for each parse. That is, after calling
                                    transitions = model.predict(partial_parses)
                                transitions[i] will be the next transition to apply to partial_parses[i].
    @param batch_size (int): The number of PartialParses to include in each minibatch


    @return dependencies (list of dependency lists): A list where each element is the dependencies
                                                    list for a parsed sentence. Ordering should be the
                                                    same as in sentences (i.e., dependencies[i] should
                                                    contain the parse for sentences[i]).
    """
    dependencies = []

    ### CODING ASSIGNMENT 3
    ### YOUR CODE HERE (~8-10 Lines)
    ### TODO:
    ###     Implement the minibatch parse algorithm.  Note that the pseudocode for this algorithm is given in the pdf handout.
    ###
    ###     Note: A shallow copy (as denoted in the PDF) can be made with the "=" sign in python, e.g.
    ###                 unfinished_parses = partial_parses[:].
    ###             Here `unfinished_parses` is a shallow copy of `partial_parses`.
    ###             In Python, a shallow copied list like `unfinished_parses` does not contain new instances
    ###             of the object stored in `partial_parses`. Rather both lists refer to the same objects.
    ###             In our case, `partial_parses` contains a list of partial parses. `unfinished_parses`
    ###             contains references to the same objects. Thus, you should NOT use the `del` operator
    ###             to remove objects from the `unfinished_parses` list. This will free the underlying memory that
    ###             is being accessed by `partial_parses` and may cause your code to crash.

    # Initialize partial parses as a list of PartialParses, one for each sentence in sentences
    partial_parses = [PartialParse(sentence) for sentence in sentences] 
    unfinished_parses = partial_parses[:] #initialize unfinished parses as a shallow copy of partial parses
    while len(unfinished_parses) !=0: #minibatch parsing until unfinished parses is empty
        minibatch = unfinished_parses[:batch_size] #take the first batch size parses in unfinished parses as a minibatch
        transitions = model.predict(minibatch) #use the model to predict the next transition for each partial parse in the minibatch

        for transition, parse_sen in zip(transitions, minibatch): #do a parse step on each partial parse in the minibatch with its predicted transition
            parse_sen.parse_step(transition)

            if len(parse_sen.buffer) == 0 and len(parse_sen.stack) == 1: #check if parse is completed (buffer should be empty, stack should be of size 1)
                unfinished_parses.remove(parse_sen) #remove the completed parse from unfinished parsespython parser_transitions.py part_c
                dependencies = [partial_parse.dependencies for partial_parse in partial_parses] #append dependencies of the completed parse to dependencies list

    ### END YOUR CODE

    return dependencies


def test_step(name, transition, stack, buf, deps,
              ex_stack, ex_buf, ex_deps):
    """Tests that a single parse step returns the expected output"""
    pp = PartialParse([])
    pp.stack, pp.buffer, pp.dependencies = stack, buf, deps

    pp.parse_step(transition)
    stack, buf, deps = (tuple(pp.stack), tuple(pp.buffer), tuple(sorted(pp.dependencies)))
    assert stack == ex_stack, \
        "{:} test resulted in stack {:}, expected {:}".format(name, stack, ex_stack)
    assert buf == ex_buf, \
        "{:} test resulted in buffer {:}, expected {:}".format(name, buf, ex_buf)
    assert deps == ex_deps, \
        "{:} test resulted in dependency list {:}, expected {:}".format(name, deps, ex_deps)
    print("{:} test passed!".format(name))


def test_parse_step():
    """Simple tests for the PartialParse.parse_step function
    Warning: these are not exhaustive
    """
    test_step("SHIFT", "S", ["ROOT", "the"], ["cat", "sat"], [],
              ("ROOT", "the", "cat"), ("sat",), ())
    test_step("LEFT-ARC", "LA", ["ROOT", "the", "cat"], ["sat"], [],
              ("ROOT", "cat",), ("sat",), (("cat", "the"),))
    test_step("RIGHT-ARC", "RA", ["ROOT", "run", "fast"], [], [],
              ("ROOT", "run",), (), (("run", "fast"),))


def test_parse():
    """Simple tests for the PartialParse.parse function
    Warning: these are not exhaustive
    """
    sentence = ["parse", "this", "sentence"]
    dependencies = PartialParse(sentence).parse(["S", "S", "S", "LA", "RA", "RA"])
    dependencies = tuple(sorted(dependencies))
    expected = (('ROOT', 'parse'), ('parse', 'sentence'), ('sentence', 'this'))
    assert dependencies == expected,  \
        "parse test resulted in dependencies {:}, expected {:}".format(dependencies, expected)
    assert tuple(sentence) == ("parse", "this", "sentence"), \
        "parse test failed: the input sentence should not be modified"
    print("parse test passed!")


class DummyModel(object):
    """Dummy model for testing the minibatch_parse function
    """
    def __init__(self, mode = "unidirectional"):
        self.mode = mode

    def predict(self, partial_parses):
        if self.mode == "unidirectional":
            return self.unidirectional_predict(partial_parses)
        elif self.mode == "interleave":
            return self.interleave_predict(partial_parses)
        else:
            raise NotImplementedError()

    def unidirectional_predict(self, partial_parses):
        """First shifts everything onto the stack and then does exclusively right arcs if the first word of
        the sentence is "right", "left" if otherwise.
        """
        return [("RA" if pp.stack[1] is "right" else "LA") if len(pp.buffer) == 0 else "S"
                for pp in partial_parses]

    def interleave_predict(self, partial_parses):
        """First shifts everything onto the stack and then interleaves "right" and "left".
        """
        return [("RA" if len(pp.stack) % 2 == 0 else "LA") if len(pp.buffer) == 0 else "S"
                for pp in partial_parses]

def test_dependencies(name, deps, ex_deps):
    """Tests the provided dependencies match the expected dependencies"""
    deps = tuple(sorted(deps))
    assert deps == ex_deps, \
        "{:} test resulted in dependency list {:}, expected {:}".format(name, deps, ex_deps)


def test_minibatch_parse():
    """Simple tests for the minibatch_parse function
    Warning: these are not exhaustive
    """

    # Unidirectional arcs test
    sentences = [["right", "arcs", "only"],
                 ["right", "arcs", "only", "again"],
                 ["left", "arcs", "only"],
                 ["left", "arcs", "only", "again"]]
    deps = minibatch_parse(sentences, DummyModel(), 2)
    test_dependencies("minibatch_parse", deps[0],
                      (('ROOT', 'right'), ('arcs', 'only'), ('right', 'arcs')))
    test_dependencies("minibatch_parse", deps[1],
                      (('ROOT', 'right'), ('arcs', 'only'), ('only', 'again'), ('right', 'arcs')))
    test_dependencies("minibatch_parse", deps[2],
                      (('only', 'ROOT'), ('only', 'arcs'), ('only', 'left')))
    test_dependencies("minibatch_parse", deps[3],
                      (('again', 'ROOT'), ('again', 'arcs'), ('again', 'left'), ('again', 'only')))

    # Out-of-bound test
    sentences = [["right"]]
    deps = minibatch_parse(sentences, DummyModel(), 2)
    test_dependencies("minibatch_parse", deps[0], (('ROOT', 'right'),))

    # Mixed arcs test
    sentences = [["this", "is", "interleaving", "dependency", "test"]]
    deps = minibatch_parse(sentences, DummyModel(mode="interleave"), 1)
    test_dependencies("minibatch_parse", deps[0],
                      (('ROOT', 'is'), ('dependency', 'interleaving'),
                      ('dependency', 'test'), ('is', 'dependency'), ('is', 'this')))
    print("minibatch_parse test passed!")


if __name__ == '__main__':
    args = sys.argv
    if len(args) != 2:
        raise Exception("You did not provide a valid keyword. Either provide 'part_c' or 'part_d', when executing this script")
    elif args[1] == "part_c":
        test_parse_step()
        test_parse()
    elif args[1] == "part_d":
        test_minibatch_parse()
    else:
        raise Exception("You did not provide a valid keyword. Either provide 'part_c' or 'part_d', when executing this script")




